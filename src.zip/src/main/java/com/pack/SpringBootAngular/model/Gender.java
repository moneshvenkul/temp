package com.pack.SpringBootAngular.model;

public enum Gender {
 MALE,FEMALE
}
